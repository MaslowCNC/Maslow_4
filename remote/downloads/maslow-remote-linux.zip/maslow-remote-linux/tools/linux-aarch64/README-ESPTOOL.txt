esptool v4.10.0 from Espressif: https://github.com/espressif/esptool
Downloaded from https://github.com/espressif/esptool/releases/download/v4.10.0/esptool-v4.10.0-linux-aarch64.tar.gz
Licensed under GPL-2.0 (LICENSE in this folder); source code at the link above.
